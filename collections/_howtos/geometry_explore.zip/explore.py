from dials.array_family import flex
data = flex.reflection_table.from_file("strong.refl")

bb = data["bbox"].parts()
flex.min(bb[4]), flex.max(bb[5])

width = bb[5] - bb[4]
x, y = data["xyzobs.px.value"].parts()[:2]

sel = width > 5
width = width.select(sel)
x = x.select(sel)
y = y.select(sel)

from matplotlib import pyplot
fig = pyplot.figure()
axis = fig.add_subplot(111, projection="3d")
axis.scatter(x.as_numpy_array(), y.as_numpy_array(), width.as_numpy_array(), marker=".")
axis.set_xlabel("X")
axis.set_ylabel("Y")
axis.set_zlabel("Width")
pyplot.show()

